package step_definition;

import cucumber.api.java.en.Then;

public class Fowzia {
	@Then("Message displayed Logout Successfully")
	public void message_displayed_Logout_Successfully() {
		 System.out.println("=============Message displayed Logout Successfully");    
	}
}
