package step_definition;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_mayur {
	@When("User Logout from the Application")
	public void user_Logout_from_the_Application() {
		 System.out.println("========User Logout from the Application");    
	}

	
}
